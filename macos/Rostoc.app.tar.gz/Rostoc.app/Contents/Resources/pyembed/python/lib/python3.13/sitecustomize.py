"""Runtime bootstrap for embedded Coro Python.

Ensures the embedded pyembed/python/lib/python3.13/site-packages is on sys.path
early and prints a minimal diagnostic banner when PY_DEBUG_CORO_PATH is set.

If CORO_DEBUG_SITE=1 is present in the environment, an extended diagnostic
dump (sys.path, executable, version, selected environment vars) is appended
to ~/Library/Logs/Coro/sitecustomize_path.log to aid debugging in packaged
and installed app contexts where stdout/stderr may be hidden.
"""
import os, sys, pathlib, datetime, json
_here = pathlib.Path(__file__).resolve().parent
site_packages = _here / 'site-packages'
if str(site_packages) not in sys.path:
  # Prepend so it wins over any accidental bundled stdlib copies.
  sys.path.insert(0, str(site_packages))
if os.environ.get('PY_DEBUG_CORO_PATH'):
  print('[sitecustomize] sys.path=', sys.path, file=sys.stderr)
if os.environ.get('CORO_DEBUG_SITE') == '1':
  try:
    log_root = pathlib.Path.home()/ 'Library' / 'Logs' / 'Coro'
    log_root.mkdir(parents=True, exist_ok=True)
    log_file = log_root / 'sitecustomize_path.log'
    interesting_env = {k:v for k,v in os.environ.items() if k.startswith(('PYTAURI','PYTHON','CORO','DYLD','PATH'))}
    payload = {
      'ts': datetime.datetime.utcnow().isoformat() + 'Z',
      'executable': sys.executable,
      'version': sys.version,
      'argv': sys.argv,
      'cwd': os.getcwd(),
      'sys_path': sys.path,
      'env': interesting_env,
    }
    with log_file.open('a', encoding='utf-8') as fh:
      fh.write(json.dumps(payload) + '\n')
  except Exception as e:  # pragma: no cover - best effort
    pass
